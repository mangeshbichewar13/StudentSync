# Student Tracker Android project

A local-first student tracker prototype with a glassmorphism UI. It has no login and does not connect to a server.

## Features
- One-time starting balance setup; the initial balance field locks after saving.
- Add/remove pocket money with category, optional note, transaction history, and balance protection.
- Monthly attendance calendar with present/absent marking.
- Study timer with subject names and daily session totals.
- Upload and save a timetable image on-device.
- Responsive phone layout and local browser storage.

## Build an APK
This folder is an Android Studio project, not a prebuilt APK. To build it:
1. Install Android Studio and an Android SDK (API 35 or newer).
2. Open this folder (`student_tracker_android`) in Android Studio.
3. Let Gradle sync, then choose **Build > Build APK(s)**.
4. Android Studio will show the APK location when the build finishes.

The build requires an internet connection for the first Gradle dependency download. No login or cloud account is needed by the app itself.

## Data note
Data is stored locally in WebView storage. Clearing app data or uninstalling can erase it. This is a prototype; it does not yet include encrypted backups, export/import, reminders, or school-specific attendance rules.
